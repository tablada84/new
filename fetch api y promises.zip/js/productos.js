const productos = [
  {
    id: 1,
    nombre: "almendras",
    precio: 200,
    img: "../img/almendra 3.jpg",
    cantidad: 1,
  },

  {
    id: 2,
    nombre: "nueces",
    precio: 500,
    img: "../img/nueces 3.jpg",
    cantidad: 1,
  },
  {
    id: 3,
    nombre: "pasas de uva",
    precio: 200,
    img: "../img/pasas negras.jpg",
    cantidad: 1,
  },
  {
    id: 4,
    nombre: "mixfrutal",
    precio: 300,
    img: "../img/mixfrutal3.jpg",
    cantidad: 1,
  },
  {
    id: 5,
    nombre: "mani",
    precio: 200,
    img: "../img/mani 3.jpg",
    cantidad: 1,
  },
];

//promises y async

const getProductos = () => {
  return new Promise((resolve, reject) => {
    if (productos.length === 0) {
      reject(new Error("no existen datos"));
    }
    setTimeout(() => {
      resolve(productos);
    }, 1500);
  });
};

//getProductos()
//.then(() => console.log(productos));

async function fetchingProductos() {
  try {
    const productosFetched = await getProductos();
    console.log(productosFetched);
  } catch (err) {
    console.log(err.menssage);
  }
}
fetchingProductos();
