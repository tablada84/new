const marketContent = document.getElementById("marketContent");
const verCarrito = document.getElementById("verCarrito");
const modalContainer = document.getElementById("modal-container");
//const pintarCarrito = document.getElementById("pintarCarrito");
const cantidadCarrito = document.getElementById("cantidadCarrito");

let carrito = JSON.parse(localStorage.getItem("carrito")) || [];
//Creando elemento
productos.forEach((produc) => {
  let content = document.createElement("div");
  content.className = "card";
  content.innerHTML = `
    <img src="${produc.img}"
    <h4>${produc.nombre}</h4>
    <a class="precio">${produc.precio}</a>
    `;
  marketContent.append(content);

  let comprar = document.createElement("button");
  comprar.innerText = "comprar";
  comprar.className = "comprar";

  content.append(comprar);

  comprar.addEventListener("click", () => {
    const repeat = carrito.some(
      (repeatProduc) => repeatProduc.id === produc.id
    );

    if (repeat) {
      carrito.map((prod) => {
        if (prod.id === produc.id) {
          prod.cantidad++;
        }
      });
    } else {
      carrito.push({
        id: produc.id,
        img: produc.img,
        nombre: produc.nombre,
        precio: produc.precio,
        cantidad: produc.cantidad,
      });

      console.log(carrito);
      carritoCounter();
      saveLocal();
    }
  });
});

const saveLocal = () => {
  localStorage.setItem("carrito", JSON.stringify(carrito));
};

JSON.parse(localStorage.getItem("carrito"));
carritoCounter();

//destructuring

let container = document.querySelector(".container");
function crearHtml(arr) {
  let html;
  arr.forEach((el) => {});
  const { nombre, precio, img } = el;
  let content = document.createElement("div");
  content.className = "card";
  content.innerHTML = `
    <img src="${img}"
    <h4>${nombre}</h4>
    <a class="precio">${precio}</a>
    `;
  contenedor.innerHTML += html;
}

//sweet alert
/* Swal.fire({
  title: "Are you sure?",
  text: "You won't be able to revert this!",
  icon: "warning",
  showCancelButton: true,
  confirmButtonColor: "#3085d6",
  cancelButtonColor: "#d33",
  confirmButtonText: "Yes, delete it!",
}).then((result) => {
  if (result.isConfirmed) {
    Swal.fire("Deleted!", "Your file has been deleted.", "success");
  }
}); */
